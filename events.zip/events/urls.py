from django.urls import path, include
from .views import RSVPCreateAPIView, UpcomingEventsAPIView, PastEventsAPIView, EventsByCategoryAPIView
from . import views

urlpatterns = [
    path('<int:event_id>/rsvp/', RSVPCreateAPIView.as_view(), name='event-rsvp'),
    path('upcoming/', UpcomingEventsAPIView.as_view(), name='upcoming-events'),
    path('past/', PastEventsAPIView.as_view(), name='past-events'),
    path('category/<int:category_id>/', EventsByCategoryAPIView.as_view(), name='events-by-category'),
    path('event/<int:pk>/archive/', views.ArchiveEventAPIView.as_view(), name='archive_event'),

]