from django.contrib import admin
from .models import Event, EventCategory
from django.utils.html import format_html


@admin.register(Event)
class EventAdmin(admin.ModelAdmin):
    list_display = ('title', 'event_date', 'category', 'is_published', 'is_featured')
    list_filter = ('is_published', 'category', 'is_featured')
    search_fields = ('title', 'description')
    prepopulated_fields = {"slug": ("title",)}

    def action_buttons(self, obj):
        return format_html(
            '<a class="button" href="{}">Preview</a> | <a class="button" href="{}">Edit</a> | <a class="button" href="{}">Archive</a>',
            f'/admin/events/event/{obj.id}/preview/',
            f'/admin/events/event/{obj.id}/change/',
            f'/admin/events/event/{obj.id}/archive/',
        )

    action_buttons.short_description = 'Actions'

    def get_urls(self):
        from django.urls import path
        urls = super().get_urls()
        custom_urls = [
            path('<int:event_id>/preview/', self.admin_site.admin_view(self.preview_event)),
            path('<int:event_id>/archive/', self.admin_site.admin_view(self.archive_event)),
        ]
        return custom_urls + urls

    def preview_event(self, request, event_id):
        event = self.get_object(request, event_id)
        return format_html('<h2>Preview: {}</h2><p>{}</p>', event.title, event.description)

    def archive_event(self, request, event_id):
        event = self.get_object(request, event_id)
        event.is_archived = True
        event.save()
        self.message_user(request, f'{event.title} has been archived.')
        return self.response_redirect(request, f'/admin/events/event/{event.id}/change/')


@admin.register(EventCategory)
class EventCategoryAdmin(admin.ModelAdmin):
    search_fields = ('name',)

